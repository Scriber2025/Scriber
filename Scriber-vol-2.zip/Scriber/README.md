Scriber - Sesli sohbet ve Mesajlaşma Uygulaması
